import biuoop.DrawSurface;
import java.awt.Color;
import java.util.List;


/**
 * Representing Ball in space. a ball is made form a center Point,
 */
public class Ball {
    /** center point of the Ball.*/
    private Point center;
    /** the Radius of the ball - Ball Size.*/
    private int r;
    /** Ball color.*/
    private Color color;
    /** The velocity vector of the MovingBall. */
    private Velocity v;
    //constructor
    /**
     *First constructor, with given point.
     * @param center point of the Ball.
     * @param r - the radius - the size of the Ball.
     * @param color - the color of the Ball.
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.v = new Velocity(0, 0);
    }

    /**
     * Second constructor, with given x,y of the center.
     * @param x coordinate of the center fo the Ball.
     * @param y coordinate of the center fo the Ball.
     * @param r - the radius - the size of the Ball.
     * @param color - the color of the Ball.
     */
    public Ball(int x, int y, int r, java.awt.Color color) {
        this(new Point(x, y), r, color);
    }

    /**
     * First constructor, with given point, and speed.
     * @param center point of the Ball.
     * @param r - the radius - the size of the Ball.
     * @param color - the color of the Ball.
     * @param v - the speed vector.
     */
    public Ball(Point center, int r, java.awt.Color color, Velocity v) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.v = v;
    }
    // accessors
    /**
     * Getter for x-coordinate.
     * @return the x value from the center point.
     */
    public int getX() {
        return (int) center.getX();
    }
    /**
     * Getter for y-coordinate.
     * @return the y value from the center point.
     */
    public int getY() {
        return (int) center.getY();
    }
    /**
     * Getter for center point.
     * @return the center point.
     */
    public Point getCenter() {
        return new Point(getX(), getY());
    }
    /**
     * Getter for the Ball size - the radius.
     * @return the r value.
     */
    public int getSize() {
        return r;
    }
    /**
     * Getter for the Ball color.
     * @return the color.
     */
    public java.awt.Color getColor() {
        return color;
    }

    /**
     * Seter for the Ball center - we need this for changing the Ball location.
     * @param center - a new center point.
     */
    protected void setCenter(Point center) {
        this.center = center;
    }

    /**
     * Method to draw the Ball on the given DrawSurface.
     * @param surface - the current screen we use.
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.getColor());
        surface.fillCircle(getX(), getY(), getSize());
    }

    /**
     * Seter for velocity, by given new Vector.
     *
     * @param v - the new vector.
     */
    protected void setVelocity(Velocity v) {
        this.v = new Velocity(v.getDx(), v.getDy());
    }

    /**
     * Seter for velocity, by given a new x,y vector coordinates.
     *
     * @param dx - delta x value.
     * @param dy - delta y value.
     */
    protected void setVelocity(double dx, double dy) {
        this.v = new Velocity(dx, dy);
    }

    /**
     * Geter for the Velocity vetor value.
     *
     * @return a new vector.
     */
    public Velocity getVelocity() {
        return new Velocity(v.getDx(), v.getDy());
    }

    /**
     * A method for cheking if hte ball hits somthing on his environment.
     * @param environment fd.
     */
    public void updateBallAndMove(Environment environment) {
        List<Collidable> obstecales = environment.getCollidables();
        for (Collidable obstecal : obstecales) {
            obstecal.hit(this, getVelocity());
        }
        moveOneStep();
    }

    /**
     * A method for moving the ball one step at a time, depending on its Velocity.
     */
    public void moveOneStep() {

        this.center = this.getVelocity().applyToPoint(this.getCenter());
    }



}



