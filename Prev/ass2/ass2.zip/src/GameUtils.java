import java.awt.Color;
import java.util.List;
import java.util.Random;

/**
 * Utility class for game helper methods, such as ball creation and movement parameters.
 */
public class GameUtils {

    /**
     * The default screen dimensions defined as a block (800x600).
     */
    public static final Block SCREEN = new Block(new Rectangle(new Point(0, 0), 800, 600),
            true);

    /**
     * Creates a new Ball object with a safe position, calculated velocity, and random color.
     *
     * @param size        - The desired radius of the ball.
     * @param environment - The environment containing collidable objects.
     * @return A new Ball object.
     */
    public static Ball createNewBallBySize(int size, Environment environment) {
        // Finds a starting position that does not overlap any existing collidables
        Point newCenter = findSafePosition(size, environment.getCollidables());
        // Calculates velocity based on size
        Velocity v = getVelocityBySize(size);
        // Gets a random color
        Color color = getRandomColor();
        return new Ball(newCenter, size, color, v);
    }


    /**
     * Finds a safe, non-colliding starting position for a ball of a given radius.
     * It randomly generates points until one is found that is not touching any collidable.
     *
     * @param r           - The radius of the ball.
     * @param environment - The array of collidable objects to check against.
     * @return A safe starting Point.
     */
    public static Point findSafePosition(int r, List<Collidable> environment) {
        Random rand = new Random();
        Point p = null;
        boolean safe = false;

        int screenWidth = (int) SCREEN.getRect().getWidth();
        int screenHeight = (int) SCREEN.getRect().getHeight();

        while (!safe) {
            // 1. Generate a random point within screen bounds
            int x = rand.nextInt(screenWidth);
            int y = rand.nextInt(screenHeight);
            p = new Point(x, y);

            boolean toucingOneOfTheCollidables = false;

            // 2. Check against ALL collidables
            for (Collidable c : environment) {
                if (c instanceof Block) {
                    Block b = (Block) c;
                    // checkPoint uses either isBallTouching (obstacle) or isBallOutdie (frame) logic
                    if (b.checkPoint(p, r)) {
                        toucingOneOfTheCollidables = true;
                        break;
                    }
                }
            }
            // A point is safe if it's not touching any collidable
            if (!toucingOneOfTheCollidables) {
                safe = true;
            }
        }
        return p;
    }

    /**
     * Calculates the speed and angle of a ball based on its size (radius).
     * Smaller balls are assigned with higher speeds.
     *
     * @param size The radius of the ball.
     * @return A new Velocity vector.
     */
    public static Velocity getVelocityBySize(int size) {
        double speed;
        if (size >= 50) {
            speed = 3.0;
        } else {
            // Formula to increase speed for smaller balls
            speed = 3.0 + ((50 - size) / 5.0);
        }
        Random rand = new Random();
        double angle = rand.nextDouble() * 360;
        return Velocity.fromAngleAndSpeed(angle, speed);
    }

    /**
     * Generates a random color for the ball.
     *
     * @return A random java.awt.Color object.
     */
    protected static Color getRandomColor() {
        Random rand = new Random();
        return new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
    }
}