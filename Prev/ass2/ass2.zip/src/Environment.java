import java.util.ArrayList;
import java.util.List;

/**
 * Represents the game environment, managing a collection of collidable objects.
 */
public class Environment {
    private List<Collidable> collidables;

    /**
     * Constructs a new Environment, initializing the list of collidable objects.
     */
    public Environment() {
        this.collidables = new ArrayList<>();
    }
    /**
     * Adds a collidable object to the environment.
     * If the object is a Block, a copy of it is created and added to ensure independence.
     *
     * @param c The Collidable object to add.
     */
    public void addCollidable(Collidable c) {
        // Uses instanceof to check for Block and create a copy (deep copy)
        if (c instanceof Block) {
            Block copy = new Block((Block) c);
            this.collidables.add(copy);
        } else {
            this.collidables.add(c);
        }
    }
    /**
     * Gets the list of all collidable objects in the environment.
     *
     * @return The list of Collidable objects.
     */
    public List<Collidable> getCollidables() {
        return collidables;
    }
}