/**
 * Class or represents a rectangular shape in space.
 */

public class Rectangle {
    private Point upperLeft;
    private double width;
    private double height;

    /**
     * Constructs a Rectangle with a given upper-left point, width, and height.
     *
     * @param upperLeft The upper-left corner point.
     * @param width The width of the rectangle.
     * @param height The height of the rectangle.
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        this.width = width;
        this.height = height;
    }
    /**
     * Gets the upper-left corner point of the rectangle.
     *
     * @return The upper-left corner Point.
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }
    /**
     * Gets the width of the rectangle.
     *
     * @return The width value.
     */
    public double getWidth() {
        return this.width;
    }
    /**
     * Gets the height of the rectangle.
     *
     * @return The height value.
     */
    public double getHeight() {
        return this.height;
    }
    /**
     * Returns the closest point on this rectangle to the given point.
     * If the point is inside the rectangle, the same point is returned.
     *
     * @param p the point to find the closest point to (may be null)
     * @return a new Point that is the closest point on the rectangle (or null if p is null)
     */
    public Point getClosestPointOnRectangle(Point p) {
        if (p == null) {
            return null;
        }
        double minX = this.upperLeft.getX();
        double minY = this.upperLeft.getY();
        double maxX = minX + this.width;
        double maxY = minY + this.height;

        double closestX = Math.max(minX, Math.min(p.getX(), maxX));
        double closestY = Math.max(minY, Math.min(p.getY(), maxY));

        return new Point(closestX, closestY);
    }

}
