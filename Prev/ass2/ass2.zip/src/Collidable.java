/**
 * Interface for objects in the game environment that can be collided with by a moving object.
 */
public interface Collidable {
    /**
     * Notifies the collidable object that it has been hit by a ball.
     * The implementation handles the collision response, typically by calculating
     * and setting a new velocity for the hitter.
     *
     * @param hitter The Ball object that initiated the collision.
     * @param currentVelocity The Velocity of the ball *before* the collision occurred.
     */
    void hit(Ball hitter, Velocity currentVelocity);
}