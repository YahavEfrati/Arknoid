import biuoop.DrawSurface;
import java.awt.Color;

/**
 * Represents a block in the game environment, which can act as a static obstacle or a frame.
 */
public class Block implements Collidable {
    private Rectangle rect;
    private boolean isFrame = false;
    private Color color;

    /**
     * Constructs a Block with a rectangular shape and defines whether it acts as a frame.
     *
     * @param rect The rectangular boundary of the block.
     * @param isFrame True if the block acts as a confining frame, false otherwise.
     */
    public Block(Rectangle rect, boolean isFrame) {
        this.isFrame = isFrame;
        this.rect = rect;
    }

    /**
     * Copy constructor. Creates a deep copy of the given Block.
     *
     * @param other The Block to copy.
     */
    public Block(Block other) {
        //copy the rectangle.
        this(other.getRect(), other.getIsFrame());
        this.setColorForBlock(other.getColor());
    }

    /**
     * Sets the color of the block.
     *
     * @param color The new color.
     */
    public void setColorForBlock(Color color) {
        this.color = color;
    }

    /**
     * Gets the color of the block.
     *
     * @return The block's color.
     */
    public Color getColor() {
        return this.color;
    }

    /**
     * Gets a copy of the block's rectangular boundary.
     *
     * @return A new Rectangle object representing the boundary.
     */
    public Rectangle getRect() {
        // Returns a copy of the Rectangle to protect internal state
        return new Rectangle(rect.getUpperLeft(), rect.getWidth(), rect.getHeight());
    }

    /**
     * Checks if the block is defined as a confining frame.
     *
     * @return True if it is a frame, false otherwise.
     */
    public boolean getIsFrame() {
        return isFrame;
    }

    /**
     * Sets whether the block acts as a confining frame.
     *
     * @param isFrame The new frame status.
     */
    public void setIsFrame(boolean isFrame) {
        this.isFrame = isFrame;
    }

    /**
     * Draws the block on the given drawing surface.
     *
     * @param surface The DrawSurface to draw on.
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        // Note: Drawing order (height/width) seems reversed, but kept as per original code structure
        surface.fillRectangle((int) rect.getUpperLeft().getX(), (int) rect.getUpperLeft().getY(),
                (int) rect.getWidth(),   (int) rect.getHeight());
    }

    /**
     * Handles the collision response when hit by a ball.
     * Delegates to specific logic based on whether the block is a frame or a regular obstacle.
     *
     * @param ball The ball that hit the block.
     * @param currentVelocity The velocity of the ball before impact.
     */
    public void hit(Ball ball, Velocity currentVelocity) {
        if (isFrame) {
            checkForHitFrame(ball, currentVelocity);
        } else {
            checkForHitBlock(ball, currentVelocity);
        }
    }

    /**
     * Checks if a point (representing a ball's center and radius) is in a position relative to the block.
     * Uses different logic based on whether the block is a frame or an obstacle.
     *
     * @param center The center point of the ball.
     * @param r The radius of the ball.
     * @return True if touching (obstacle) or outside (frame), false otherwise.
     */
    public boolean checkPoint(Point center, int r) {
        // Note: isBallOutdie should be isBallOutside
        return isFrame ? isBallOutdie(center, r) : isBallTouching(center, r);
    }

    /**
     * Block obstecal Logic (Handles collisions for regular obstacles).
     * @param ball The ball that hit the block.
     * @param currentVelocity The velocity of the ball before impact.
     */
    public void checkForHitBlock(Ball ball, Velocity currentVelocity) {
        double minX = rect.getUpperLeft().getX();
        double minY = rect.getUpperLeft().getY();
        double maxX = minX + rect.getWidth();
        double maxY = minY + rect.getHeight();
        Point currentCenter = ball.getCenter();
        int size = ball.getSize();
        Point nextCenter = currentVelocity.applyToPoint(ball.getCenter());
        // Find the closest point to the ball
        double closestX = Math.max(minX, Math.min(nextCenter.getX(), maxX));
        double closestY = Math.max(minY, Math.min(nextCenter.getY(), maxY));
        double distanceX = nextCenter.getX() - closestX;
        double distanceY = nextCenter.getY() - closestY;
        double distanceSquared = (distanceX * distanceX) + (distanceY * distanceY);
        if (distanceSquared > size * size) {
            // No collision
            return;
        }
        // --- Vertical Alignment Check (Is the ball currently 'level' with the wall?)
        // We check if the ball's Y-range overlaps with the rectangle's Y-range.
        // If not, it can't hit the side walls, so we skip the next two checks.
        boolean isYAligned = (currentCenter.getY() + size > minY)
                && (currentCenter.getY() - size < maxY);

        // Use incoming velocity components for correct flip decisions
        double dx = currentVelocity.getDx();
        double dy = currentVelocity.getDy();

        // 1. Hit Left Wall (coming from the far left)
        if (currentCenter.getX() < minX && nextCenter.getX() + size > minX && isYAligned) {
            ball.setVelocity(-dx, dy);
        // 2. Hit Right Wall (coming from the far right)
        } else if (currentCenter.getX() > maxX && nextCenter.getX() - size < maxX && isYAligned) {
            ball.setVelocity(-dx, dy);
        }

        // --- Horizontal Alignment Check (Used for up/down collisions) ---
        // We check if the ball's X-range overlaps the rectangle's X-range.
        boolean isXAligned = (currentCenter.getX() + size > minX)
                && (currentCenter.getX() - size < maxX);

        // 3. Hit Top Wall (coming from the top)
        if (currentCenter.getY() <= minY && nextCenter.getY() + size >= minY && isXAligned) {
            ball.setVelocity(dx, -dy);
        }

        // 4. Hit Bottom Wall (coming from the bottom)
        if (currentCenter.getY() >= maxY && nextCenter.getY() - size <= maxY && isXAligned) {
            ball.setVelocity(dx, -dy);
        }
    }

    /**
     * Checks if the ball's bounding box is overlapping with the block's bounding box.
     * Used for initial position safety check (obstacle).
     *
     * @param center The center point of the ball.
     * @param r The radius of the ball.
     * @return True if the ball is touching or overlapping the block.
     */
    public boolean isBallTouching(Point center, int r) {
        double minX = rect.getUpperLeft().getX();
        double minY = rect.getUpperLeft().getY();
        double maxX = minX + rect.getWidth();
        double maxY = minY + rect.getHeight();
        return (center.getX() + r > minX) && (center.getX() - r < maxX)
                && (center.getY() + r > minY) && (center.getY() - r < maxY);
    }

    /**
     * Frame Logic (Handles collisions for confining frames).
     * @param ball The ball that hit the block.
     * @param currentVelocity The velocity of the ball before impact.
     */
    public void checkForHitFrame(Ball ball, Velocity currentVelocity) {
        double nextX = ball.getX() + currentVelocity.getDx();
        double nextY = ball.getY() + currentVelocity.getDy();
        int r = ball.getSize();

        double minX = rect.getUpperLeft().getX();
        double minY = rect.getUpperLeft().getY();
        double maxX = minX + rect.getWidth();
        double maxY = minY + rect.getHeight();

        double dx = currentVelocity.getDx();
        double dy = currentVelocity.getDy();
        boolean velocityChanged = false;

        // Check horizontal boundaries
        if (nextX + r >= maxX && dx > 0) {
            ball.setVelocity(-dx, dy);
            velocityChanged = true;
        } else if (nextX - r <= minX && dx < 0) {
            ball.setVelocity(-dx, dy);
            velocityChanged = true;
        }

        dx = ball.getVelocity().getDx(); // Update dx after potential horizontal flip

        // Check vertical boundaries
        if (nextY + r >= maxY && dy > 0) {
            velocityChanged = true;
            ball.setVelocity(dx, -dy);
        } else if (nextY - r <= minY && dy < 0) {
            velocityChanged = true;
            ball.setVelocity(dx, -dy);
        }

        // Clamp position if a velocity change occurred
        if (velocityChanged) {
            correctPositionForFrame(ball, minX, maxX, minY, maxY);
        }
    }

    /**
     * Clamps the ball's position to the inside boundaries of the frame.
     * This prevents the ball from getting stuck outside the frame walls.
     *
     * @param ball The ball to correct.
     * @param minX The minimum X boundary.
     * @param maxX The maximum X boundary.
     * @param minY The minimum Y boundary.
     * @param maxY The maximum Y boundary.
     */
    private void correctPositionForFrame(Ball ball, double minX, double maxX, double minY, double maxY) {
        int r = ball.getSize();
        double x = ball.getX();
        double y = ball.getY();

        // Clamp X
        if (x + r > maxX) {
            x = maxX - r;
        } else if (x - r < minX) {
            x = minX + r;
        }
        // Clamp Y
        if (y + r > maxY) {
            y = maxY - r;
        } else if (y - r < minY) {
            y = minY + r;
        }
        // Set the corrected center point
        ball.setCenter(new Point(x, y));
    }

    /**
     * Checks if the ball is outside the defined boundaries.
     * Used for initial position safety check (frame).
     *
     * @param center The center point of the ball.
     * @param r The radius of the ball.
     * @return True if the ball is outside the frame, false otherwise.
     */
    public boolean isBallOutdie(Point center, int r) {
        double minX = rect.getUpperLeft().getX();
        double minY = rect.getUpperLeft().getY();
        double maxX = minX + rect.getWidth();
        double maxY = minY + rect.getHeight();
        return (center.getX() + r > maxX || center.getX() - r < minX
                || center.getY() + r > maxY || center.getY() - r < minY);
    }


}